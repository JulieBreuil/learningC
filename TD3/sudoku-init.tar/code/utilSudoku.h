int lireSudoku(FILE *fich,int sudoku[9][9]);
int ecrireSudoku(FILE *fich,int sudoku[9][9]);

