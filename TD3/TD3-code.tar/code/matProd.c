#include <stdio.h>
#include "matrice.h"
#include "matProd.h"

int matProd(int A[N][N], int B[N][N], int C[N][N])
{

  return 0;
}
