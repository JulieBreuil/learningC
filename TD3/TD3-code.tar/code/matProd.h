#include "matrice.h"

int matProd(int A[N][N], int B[N][N], int C[N][N]);
