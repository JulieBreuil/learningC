#ifndef MATRICE_H
#define MATRICE_H

// definition of matrices sizes
#define N 9

#endif
