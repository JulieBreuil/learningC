#include "matrice.h"

int lireMatrice(FILE *fich,int mat[N][N]);
int ecrireMatrice(FILE *fich,int mat[N][N]);
